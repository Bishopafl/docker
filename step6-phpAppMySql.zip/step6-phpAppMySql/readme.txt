myphpapp.app
-------------
In this example, I will be setting up a php application using apache that is attached to a
MySQL database. The files will also be volumn controlled and attached to the structure on 
my local machine for active development.

within the docker-compose.yml file, I have configured the MySQL connection information, 
the table name to use for the container as well as the volume mounting required to update 
the code for the file. 